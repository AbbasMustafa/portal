/**
 * @description The raw dinosaur data, put in function to avoid global variable
 * @returns An array of dinosaur objects (plus a pigeon)
 */
// Dinos Data Wrape into function for prevent global variable
const dinosData = (function(){
    const data = {
        "Dinos": [
            {
                "species": "Triceratops",
                "weight": 13000,
                "height": 114,
                "diet": "herbavor",
                "where": "North America",
                "when": "Late Cretaceous",
                "fact": "First discovered in 1889 by Othniel Charles Marsh"
            },
            {
                "species": "Tyrannosaurus Rex",
                "weight": 11905,
                "height": 144,
                "diet": "carnivor",
                "where": "North America",
                "when": "Late Cretaceous",
                "fact": "The largest known skull measures in at 5 feet long."
            },
            {
                "species": "Anklyosaurus",
                "weight": 10500,
                "height": 55,
                "diet": "herbavor",
                "where": "North America",
                "when": "Late Cretaceous",
                "fact": "Anklyosaurus survived for approximately 135 million years."
            },
            {
                "species": "Brachiosaurus",
                "weight": 70000,
                "height": "372",
                "diet": "herbavor",
                "where": "North America",
                "when": "Late Jurasic",
                "fact": "An asteroid was named 9954 Brachiosaurus in 1991."
            },
            {
                "species": "Stegosaurus",
                "weight": 11600,
                "height": 79,
                "diet": "herbavor",
                "where": "North America, Europe, Asia",
                "when": "Late Jurasic to Early Cretaceous",
                "fact": "The Stegosaurus had between 17 and 22 seperate places and flat spines."
            },
            {
                "species": "Elasmosaurus",
                "weight": 16000,
                "height": 59,
                "diet": "carnivor",
                "where": "North America",
                "when": "Late Cretaceous",
                "fact": "Elasmosaurus was a marine reptile first discovered in Kansas."
            },
            {
                "species": "Pteranodon",
                "weight": 44,
                "height": 20,
                "diet": "carnivor",
                "where": "North America",
                "when": "Late Cretaceous",
                "fact": "Actually a flying reptile, the Pteranodon is not a dinosaur."
            },
            {
                "species": "Pigeon",
                "weight": 0.5,
                "height": 9,
                "diet": "herbavor",
                "where": "World Wide",
                "when": "Holocene",
                "fact": "All birds are living dinosaurs."
            }
        ]
    }

    function getData(){
        return data
    }

    return {
        getData
    }
})()


// Create Dino Constructor
/**
 * @description Dinsoure Construstion
 * @param {Object} dinoData A single dinosaur object
 * @returns An object of dinosaur objects 
 */
function Dino(dinoObj){
    const species = dinoObj.species;
    const weight = parseFloat(dinoObj.weight);
    const height = parseFloat(dinoObj.height);
    const diet = dinoObj.diet;
    const where = dinoObj.where;
    const when = dinoObj.when;
    const fact = dinoObj.fact;
    
    const getSpecies = function(){
        return species
    }
    const getWeight = function(){
        return weight
    }
    const getHeight = function(){
        return height
    }
    const getDiet = function(){
        return diet
    }
    const getWhere = function(){
        return where
    }
    const getWhen = function(){
        return when
    }
    const getFact = function(){
        return fact
    }

    return {
        getSpecies: getSpecies(),
        getWeight: getWeight(),
        getHeight: getHeight(),
        getDiet: getDiet(),
        getWhere: getWhere(),
        getWhen: getWhen(),
        getFact: getFact()

    }
}

/**
 * @description Dinsoure Construstion
 * @returns An Array Contain all Dino Objects
 */
function getDinoData(){
    // get Dinos Data
    const data = dinosData.getData()

    // Create Dino Objects
    const Dinos = []
    data['Dinos'].forEach(obj => {
        Dinos.push( Dino(obj) )
    });
    
    return Dinos
}


// Create Human Object
/**
 * @description Human Construstion
 * @param {Object} Human Object A single human object
 * @returns human Object
 */
const Human = function(obj){
    const name = obj.name;
    const heightFeet = parseFloat(obj.heightFeet);
    const heightInch = parseFloat(obj.heightInch);
    const weight = parseFloat(obj.weight, 10);
    const diet = obj.diet;

    const getName = function(){
        return name;
    }
    const getHeightFeet = function(){
        return heightFeet
    }
    const getHeightInch = function(){
        return heightInch
    }
    const getWeight = function(){
        return weight
    }
    const getDiet = function(){
        return diet
    }
    return {
        name: getName(), 
        heightFeet: getHeightFeet(),
        heightInch: getHeightInch(),
        weight: getWeight(),
        diet: getDiet()
    }
}

// Use IIFE to get human data from form
 const humanData = (function getFormData(){

    const name = document.querySelector('#name');
    const heightFeet = document.querySelector('#feet');
    const heightInch = document.querySelector('#inches');
    const weight = document.querySelector('#weight');
    const diet = document.querySelector('#diet')

    return {
        name,
        heightFeet,
        heightInch,
        weight,
        diet
    }
})()


// set human object form DOM element for Human data
const humanObject = function(elements){
    
    if(formValidation(elements)){
        return false;
    }

    const name = elements.name.value;
    const heightFeet = elements.heightFeet.value;
    const heightInch = elements.heightInch.value;
    const weight = elements.weight.value;
    const diet = elements.diet.value;

    return Human({ name, heightFeet, heightInch, weight, diet })

}

// form Validation
/**
 * @description form Validation
 * @param {Array} Array of DOM Objects (input Fields)
 * @returns {Boolean} True or False Condition on Empty Field
 */
function formValidation(elements){
    let flag = false;
    Object.values(elements).forEach(element => {
        if(element.value === ""){
            element.classList.add('red-border');
            flag = true;
        }else{
            element.classList.remove('red-border');
        }
    })

    return flag;
}

// compare method
const compareDino = function(Dinos ,Human){
    
    const diffData = [];

    Dinos.forEach(dino => {

        const humanHeight = (Human.heightFeet*12) + Human.heightInch
        console.log(humanHeight);
        const heightDiff = ( (dino.getHeight / humanHeight)*100 ).toFixed(2);

        const weightDiff = ( (dino.getWeight/Human.weight)*100 ).toFixed(2)

        diffData.push(
            {
                name: dino.getSpecies,
                heightDiff: heightDiff,
                weightDiff: weightDiff,
                fact: dino.getFact,
                diet: dino.getDiet
            }
        )
    })

    console.log(diffData);
    return diffData
}

// Generate Tiles for each Dino in Array
const generatetiles = function(data, humanData){
    let tiles = [];
  
    data.forEach(item => {
        tiles.push(`
        <div class="grid-item">
            <h3>${item.name}</h3>
            <img src="./images/${item.name.toLowerCase()}.png" alt="">
            <p>
                ${item.fact} <br>
                Weight difference: ${item.weightDiff}%  <br>
                Height difference: ${item.heightDiff}%
            </p>
        </div>
        `);
    })

    // Add Human tile into an array 
    const humanTile = `
    <div class="grid-item">
        <h3>${humanData.name}</h3>
        <img src="./images/human.png" alt="">
    </div>
    `
    tiles.splice(4, 0, humanTile);

    return tiles.join("")
}
    // Add tiles to DOM
const addTiles = function(tiles){
    const grid =  document.querySelector('#grid')
    grid.innerHTML = tiles;
}


// Remove form from screen
const removeForm = function(){
    document.querySelector('#dino-compare').remove();
}

// On button click, prepare and display infographic
function btnClicked(){
    const humanObj = humanObject(humanData)
    if(!humanObj) return; // return  if Form is not validate
    const dinosObj = getDinoData()
    const diffData = compareDino(dinosObj, humanObj)
    const tiles = generatetiles( diffData, humanObj )
    removeForm()
    addTiles(tiles)
}